package com.yash.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.yash.model.Employee;

@RestController
@RequestMapping("/web")
public class WebController {
	
	@RequestMapping("/home")
	public ModelAndView getString() {
		ModelAndView mav=new ModelAndView("index");
		return mav;
	}
	
	
	@RequestMapping("/register")
	public ModelAndView regEmployee(Employee emp) {
		ModelAndView mav=new ModelAndView("register");
		System.out.println(emp.getTest());
		return mav;
	}
	
}
