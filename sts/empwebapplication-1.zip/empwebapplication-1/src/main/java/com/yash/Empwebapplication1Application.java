package com.yash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Empwebapplication1Application {

	public static void main(String[] args) {
		SpringApplication.run(Empwebapplication1Application.class, args);
		
	}

}
