package com.yash.serviceimpl;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.yash.model.Employee;
import com.yash.service.EmployeeRepo;


@Service
public class EmployeeService {
	
	
	@Autowired
	EmployeeRepo er;
	
	public boolean saveEmp(Employee emp) {
		
		emp.getImage();
		er.save(emp);
		System.out.println("called");
		return true;
	}

}
