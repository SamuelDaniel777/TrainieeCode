package com.yash.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.yash.model.Employee;
import com.yash.serviceimpl.EmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService es;
	
	@RequestMapping(value = "/save",method = RequestMethod.POST)
	public String saveEmp(Employee emp) {
		es.saveEmp(emp);
		return "register";
	}
}
